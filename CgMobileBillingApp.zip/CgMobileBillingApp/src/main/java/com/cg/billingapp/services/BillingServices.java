package com.cg.billingapp.services;
import java.util.List;

import org.springframework.stereotype.Service;

import com.cg.billingapp.exceptions.CustomerDetailsNotFoundException;
import com.cg.billingapp.exceptions.PlanNotFoundException;
import com.cg.billingapp.exceptions.PostPaidAccountNotFoundException;
import com.cg.billingapp.pojos.Address;
import com.cg.billingapp.pojos.Bill;
import com.cg.billingapp.pojos.Customer;
import com.cg.billingapp.pojos.Plan;
import com.cg.billingapp.pojos.PostPaidAccount;


public interface BillingServices {
	public List<Plan> getAllPostPaidPlanDetails();
	Customer acceptCustomerDetails(Customer customer);
	PostPaidAccount openPostPaidAccount (int customerId) throws CustomerDetailsNotFoundException;
	boolean changePostPaidAccountPlan(int customerId,long mobileNo, int newPlanCode) throws CustomerDetailsNotFoundException, PostPaidAccountNotFoundException,PlanNotFoundException;
	Bill calculatePostPaidAccountBill(int customerId,long mobileNo, int localSMS , int localCallsDurationInMin, int stdCallSDurationInMin, String month) throws CustomerDetailsNotFoundException, PostPaidAccountNotFoundException;
	List<Bill> getPostPaidAccountAllBillDetails(int customerId,long mobileNo) throws CustomerDetailsNotFoundException, PostPaidAccountNotFoundException;
	Bill getPostPaidAccountBillDetails(int customerId,long mobileNo, String month) throws CustomerDetailsNotFoundException, PostPaidAccountNotFoundException;
	PostPaidAccount getPostPaidAccountDetails(int customerId,long mobileNo, String month) throws CustomerDetailsNotFoundException, PostPaidAccountNotFoundException;
	boolean  changeInAddress (int customerId ,Address address)  throws CustomerDetailsNotFoundException;
	Customer getCustomerDetails(int customerId)  throws CustomerDetailsNotFoundException;
}
