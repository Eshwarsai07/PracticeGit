package com.cg.billingapp.exceptions;

public class PostPaidAccountNotFoundException extends Exception {

	public PostPaidAccountNotFoundException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public PostPaidAccountNotFoundException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public PostPaidAccountNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public PostPaidAccountNotFoundException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}
	

}
