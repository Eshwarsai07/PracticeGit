package com.cg.billingapp.daos;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cg.billingapp.pojos.PostPaidAccount;

@Repository
public interface PostPaidAccountDAO  extends JpaRepository<PostPaidAccount, Long>{

}
