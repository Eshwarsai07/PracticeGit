package com.cg.billingapp.pojos;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name="bill")
public class Bill {
	@Id
	@GeneratedValue(strategy= GenerationType.AUTO)
	private int id;
	private String month;
	private int localSMS;
	private int localCallsDurationInMin , stdCallSDurationInMin;
	private int localSMSAmount , localCallsAmount,stdCallSAmount ; 
	
	private double totalBillAmount;
	@ManyToOne
	private PostPaidAccount postPaidAccount;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getMonth() {
		return month;
	}
	public void setMonth(String month) {
		this.month = month;
	}
	public int getLocalSMS() {
		return localSMS;
	}
	public void setLocalSMS(int localSMS) {
		this.localSMS = localSMS;
	}
	public int getLocalCallsDurationInMin() {
		return localCallsDurationInMin;
	}
	public void setLocalCallsDurationInMin(int localCallsDurationInMin) {
		this.localCallsDurationInMin = localCallsDurationInMin;
	}
	public int getStdCallSDurationInMin() {
		return stdCallSDurationInMin;
	}
	public void setStdCallSDurationInMin(int stdCallSDurationInMin) {
		this.stdCallSDurationInMin = stdCallSDurationInMin;
	}
	public int getLocalSMSAmount() {
		return localSMSAmount;
	}
	public void setLocalSMSAmount(int localSMSAmount) {
		this.localSMSAmount = localSMSAmount;
	}
	public int getLocalCallsAmount() {
		return localCallsAmount;
	}
	public void setLocalCallsAmount(int localCallsAmount) {
		this.localCallsAmount = localCallsAmount;
	}
	public int getStdCallSAmount() {
		return stdCallSAmount;
	}
	public void setStdCallSAmount(int stdCallSAmount) {
		this.stdCallSAmount = stdCallSAmount;
	}
	public double getTotalBillAmount() {
		return totalBillAmount;
	}
	public void setTotalBillAmount(double totalBillAmount) {
		this.totalBillAmount = totalBillAmount;
	}
	
	
	
	
	
}