package com.cg.billingapp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.billingapp.pojos.Bill;
import com.cg.billingapp.pojos.Customer;
import com.cg.billingapp.pojos.Plan;
import com.cg.billingapp.pojos.PostPaidAccount;
import com.cg.billingapp.services.BillingServices;

@RestController
@RequestMapping("/postpaid")
public class BillingAppController {
	
	    @Autowired
	    private BillingServices postPaidService;
	    
	    @GetMapping("/getallpostpaidplandetails")
	    public ResponseEntity<List<Plan>> getAllPostPaidPlanDetails() {
			return new ResponseEntity<List<Plan>>(postPaidService.getAllPostPaidPlanDetails(), HttpStatus.OK);
	       
	    }

	    @PostMapping("/addcustomerdetails")
	    public ResponseEntity<String> acceptCustomerDetails(@RequestBody Customer customer) {
			
	    	customer=postPaidService.acceptCustomerDetails(customer);
	    	return  new ResponseEntity<String>("Customer details successfully added id: "+customer.getId(), HttpStatus.CREATED);
	       
	    }
	    
	    @PostMapping("/addpostpaidaccount")
	    public ResponseEntity<PostPaidAccount> openPostPaidAccount(@RequestParam int customerId) {
			
	    	return null;
	       
	    }

	    @PutMapping("/updatepostpaidaccount/{plan}")
	    public ResponseEntity<Boolean> changePostPaidAccountPlan(@RequestParam int customerId, @RequestParam long mobileNo,
	            @RequestParam int newPlanCode) {
					return null;
	       
	    }

	    @GetMapping("/getpostpaidaccountbill")
	    public ResponseEntity<Bill> calculatePostPaidAccountBill(@RequestParam int customerId, @RequestParam long mobileNo,
	            @RequestParam int localSMS, @RequestParam int localCallsDurationInMin,
	            @RequestParam int stdCallSDurationInMin, @RequestParam String month) {
					return null;
	        
	    }

	    @GetMapping("/getAllBillDetails")
	    public ResponseEntity<List<Bill>> getPostPaidAccountAllBillDetails(@RequestParam int customerId,
	            @RequestParam long mobileNo) {
					return null;
	       

}
	  }
