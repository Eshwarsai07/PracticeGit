package com.cg.billingapp.pojos;
import java.util.Map;

import org.hibernate.annotations.ManyToAny;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Entity
public class PostPaidAccount {
	@Id
	private long mobileNo;
	
	@ManyToOne
	private Plan plan;
	@OneToMany
	private Map<String, Bill> bills ;
	public long getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(long mobileNo) {
		this.mobileNo = mobileNo;
	}
	public Plan getPlan() {
		return plan;
	}
	public void setPlan(Plan plan) {
		this.plan = plan;
	}
	public Map<String, Bill> getBills() {
		return bills;
	}
	public void setBills(Map<String, Bill> bills) {
		this.bills = bills;
	}
	
	
	
	
	
}