package com.cg.billingapp.exceptions;

public class InvalidMobileNumberException extends Exception{
	public InvalidMobileNumberException() {
	}
	public InvalidMobileNumberException(String message) {
		super(message);
	}
}
