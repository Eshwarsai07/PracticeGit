package com.cg.billingapp.daos;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cg.billingapp.pojos.Bill;

@Repository
public interface BillDAO extends JpaRepository<Bill,Integer> {

}
