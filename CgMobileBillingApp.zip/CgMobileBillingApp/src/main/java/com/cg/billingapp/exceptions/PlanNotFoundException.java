package com.cg.billingapp.exceptions;

public class PlanNotFoundException extends Exception {

	public PlanNotFoundException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public PlanNotFoundException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public PlanNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public PlanNotFoundException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}
	
	

}
