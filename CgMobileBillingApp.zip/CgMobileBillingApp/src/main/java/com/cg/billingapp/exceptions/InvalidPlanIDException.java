package com.cg.billingapp.exceptions;

public class InvalidPlanIDException extends Exception{
	public InvalidPlanIDException() {
	}
	public InvalidPlanIDException(String message) {
		super(message);
	}
}
