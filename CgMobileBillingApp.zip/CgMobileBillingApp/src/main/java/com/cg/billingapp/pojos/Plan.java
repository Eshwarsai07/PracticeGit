package com.cg.billingapp.pojos;

import java.util.List;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Entity
public class Plan {
	
	@Id
	@GeneratedValue(strategy= GenerationType.AUTO)
	private int code;
	private String name;
	private double localSMSCharge;
	private double monthlyRentalAmount,localCallCharge,stdCallCharge;
	@OneToMany
	private List<PostPaidAccount> postPaidAccounts;
	public int getCode() {
		return code;
	}
	public void setCode(int code) {
		this.code = code;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getLocalSMSCharge() {
		return localSMSCharge;
	}
	public void setLocalSMSCharge(double localSMSCharge) {
		this.localSMSCharge = localSMSCharge;
	}
	public double getMonthlyRentalAmount() {
		return monthlyRentalAmount;
	}
	public void setMonthlyRentalAmount(double monthlyRentalAmount) {
		this.monthlyRentalAmount = monthlyRentalAmount;
	}
	public double getLocalCallCharge() {
		return localCallCharge;
	}
	public void setLocalCallCharge(double localCallCharge) {
		this.localCallCharge = localCallCharge;
	}
	public double getStdCallCharge() {
		return stdCallCharge;
	}
	public void setStdCallCharge(double stdCallCharge) {
		this.stdCallCharge = stdCallCharge;
	}
	
	
	
	

	
}
