 package com.cg.billingapp.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.billingapp.daos.CustomerDAO;
import com.cg.billingapp.daos.PlanDAO;
import com.cg.billingapp.daos.PostPaidAccountDAO;
import com.cg.billingapp.exceptions.CustomerDetailsNotFoundException;
import com.cg.billingapp.exceptions.PlanNotFoundException;
import com.cg.billingapp.exceptions.PostPaidAccountNotFoundException;
import com.cg.billingapp.pojos.Address;
import com.cg.billingapp.pojos.Bill;
import com.cg.billingapp.pojos.Customer;
import com.cg.billingapp.pojos.Plan;
import com.cg.billingapp.pojos.PostPaidAccount;

@Service
public class BiilingServicesImpl implements BillingServices{

	@Autowired
	private PostPaidAccountDAO postPaidAccountDAO;
	
	@Autowired
	private PlanDAO planDAO;
	@Autowired
	private CustomerDAO customerDAO ;
	
	@Override
	public List<Plan> getAllPostPaidPlanDetails() {
		return planDAO.findAll();
	}

	@Override
	public Customer acceptCustomerDetails(Customer customer) {
    
		return customerDAO.save(customer);
	}

	@Override
	public PostPaidAccount openPostPaidAccount(int customerId) throws CustomerDetailsNotFoundException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean changePostPaidAccountPlan(int customerId, long mobileNo, int newPlanCode)
			throws CustomerDetailsNotFoundException, PostPaidAccountNotFoundException, PlanNotFoundException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Bill calculatePostPaidAccountBill(int customerId, long mobileNo, int localSMS, int localCallsDurationInMin,
			int stdCallSDurationInMin, String month)
			throws CustomerDetailsNotFoundException, PostPaidAccountNotFoundException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Bill> getPostPaidAccountAllBillDetails(int customerId, long mobileNo)
			throws CustomerDetailsNotFoundException, PostPaidAccountNotFoundException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Bill getPostPaidAccountBillDetails(int customerId, long mobileNo, String month)
			throws CustomerDetailsNotFoundException, PostPaidAccountNotFoundException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public PostPaidAccount getPostPaidAccountDetails(int customerId, long mobileNo, String month)
			throws CustomerDetailsNotFoundException, PostPaidAccountNotFoundException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean changeInAddress(int customerId, Address address) throws CustomerDetailsNotFoundException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Customer getCustomerDetails(int customerId) throws CustomerDetailsNotFoundException {
		// TODO Auto-generated method stub
		return null;
	}

}
