package com.cg.billingapp.daos;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cg.billingapp.pojos.Customer;

@Repository
public interface CustomerDAO extends JpaRepository< Customer,Integer> {

}
