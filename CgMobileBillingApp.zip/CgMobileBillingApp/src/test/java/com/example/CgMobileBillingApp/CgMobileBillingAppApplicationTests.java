package com.example.CgMobileBillingApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CgMobileBillingAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
